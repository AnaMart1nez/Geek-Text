package com.rest.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "creditcards")

public class Creditcard {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Creditcardid")
	private Long CreditCardID;
	
	@Column(name = "Creditcardnumber")
	private Integer creditcardnumber;

	@Column(name = "Cardholdername")
	private String cardname;
	
	@Column(name = "Expirationdate")
	private Integer expirationdate;
	
	@Column(name = "Cvv")
	private Integer cvv;
	
	@ManyToOne
	@JoinColumn(name = "UserID", nullable=false)
	private User user;
	
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Creditcard() {
		super();	
	}


	public Creditcard(Long creditCardID, Integer creditcardnumber, String cardname, Integer expirationdate, Integer cvv,
			User user) {
		super();
		CreditCardID = creditCardID;
		this.creditcardnumber = creditcardnumber;
		this.cardname = cardname;
		this.expirationdate = expirationdate;
		this.cvv = cvv;
		this.user = user;
	}

	public Long getCreditCardID() {
		return CreditCardID;
	}

	public void setCreditCardID(Long creditCardID) {
		CreditCardID = creditCardID;
	}


	public String getCardname() {
		return cardname;
	}

	public void setCardname(String cardname) {
		this.cardname = cardname;
	}

	public Integer getCreditcardnumber() {
		return creditcardnumber;
	}

	public void setCreditcardnumber(Integer creditcardnumber) {
		this.creditcardnumber = creditcardnumber;
	}

	public Integer getExpirationdate() {
		return expirationdate;
	}

	public void setExpirationdate(Integer expirationdate) {
		this.expirationdate = expirationdate;
	}

	public Integer getCvv() {
		return cvv;
	}

	public void setCvv(Integer cvv) {
		this.cvv = cvv;
	}


	
}
