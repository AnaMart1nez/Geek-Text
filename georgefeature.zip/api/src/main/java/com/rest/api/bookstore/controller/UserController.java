package com.rest.api.bookstore.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.rest.api.model.Creditcard;
import com.rest.api.model.Shippingaddress;
import com.rest.api.model.User;
import com.rest.api.repository.CreditCardRepository;
import com.rest.api.repository.ShippingAddressRepository;
import com.rest.api.repository.UserRepository;

@Controller
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private CreditCardRepository creditRepository;
	@Autowired
	private ShippingAddressRepository addressRepository;

	/*
	 * // forgot password link
	 * 
	 * @PostMapping("/forgotpassword") private String forgotPassword(User user) { if
	 * (user.getUsername() == null) { System.err.println("username not found"); }
	 * else { Optional<User> userOptional =
	 * userRepository.findByUsername(user.getUsername()); if
	 * (userOptional.isPresent()) { User editUser = userOptional.get();
	 * userRepository.save(editUser); } } return "redirect:/index"; }
	 */
	
	// list all users
	@GetMapping("/list")
	private String getAll(Model model) {
		model.addAttribute("users", userRepository.findAll());
		return "user_list";
	}
	
	// list all credit cards
	@GetMapping("/list/creditcard")
	private String getAllCreditcards(Model model) {
		model.addAttribute("creditcards", creditRepository.findAll());
		return "user_creditcard";
	}

	// list all shipping address
	@GetMapping("/list/shippingaddress")
	private String getAllShippingaddress(Model model) {
		model.addAttribute("shippingaddresses", addressRepository.findAll());
		return "user_shippingaddress";
	}
	
	// add or edit users
	@GetMapping(path = { "/add", "edit/{id}" })
	private String addForm(@PathVariable("id") Optional<Long> id, Model model) {
		if (id.isPresent()) {
			model.addAttribute("user", userRepository.findById(id.get()));
		} else {
			model.addAttribute("user", new User());
		}
		return "add_edit_user";
	}
	
	// add or edit credit cards
	@GetMapping(path = { "/add/creditcard", "edit/creditcard/{id}" })
	private String addFormCreditcard(@PathVariable("id") Optional<Long> CreditCardID, Model model) {
		if (CreditCardID.isPresent()) {
			model.addAttribute("creditcard", creditRepository.findById(CreditCardID.get()));
		} else {
			model.addAttribute("creditcard", new Creditcard());
		}
		return "add_edit_creditcard";
	}

	// add or edit shipping addresses
		@GetMapping(path = { "/add/shippingaddress", "edit/shippingaddress/{id}" })
		private String addFormShippingaddress(@PathVariable("id") Optional<Long> shippingID, Model model) {
			if (shippingID.isPresent()) {
				model.addAttribute("shippingaddress", addressRepository.findById(shippingID.get()));
			} else {
				model.addAttribute("shippingaddress", new Shippingaddress());
			}
			return "add_edit_shippingaddress";
		}
		
	// addedit command for users
	@PostMapping("/addEdit")
	private String insertOrUpdate(User user) {
		if (user.getId() == null) {
			userRepository.save(user);
		} else {
			Optional<User> userOptional = userRepository.findById(user.getId());
			if (userOptional.isPresent()) {
				User editUser = userOptional.get();
				editUser.setUsername(user.getUsername());
				editUser.setPassword(user.getPassword());
				editUser.setFirstname(user.getFirstname());
				editUser.setLastname(user.getLastname());
				editUser.setEmail(user.getEmail());
				editUser.setNickname(user.getNickname());
				userRepository.save(editUser);
			}
		}
		return "redirect:/index";
	}
	
	// addedit command for credit cards
	@PostMapping("/addEdit/creditcard")
	private String insertOrUpdateCreditcard(Creditcard creditcard, User user) {
		if (creditcard.getCreditCardID() == null) {
			creditRepository.save(creditcard);
		} else {
			Optional<Creditcard> creditcardOptional = creditRepository.findById(creditcard.getCreditCardID());
			if (creditcardOptional.isPresent()) {
				Creditcard editCreditcard = creditcardOptional.get();
				editCreditcard.setCreditcardnumber(creditcard.getCreditcardnumber());
				editCreditcard.setCardname(creditcard.getCardname());
				editCreditcard.setExpirationdate(creditcard.getExpirationdate());
				editCreditcard.setCvv(creditcard.getCvv());
				creditRepository.save(editCreditcard);
			}
		}
		return "redirect:/api/users/list/creditcard";
	}

	// addedit command for shipping address
		@PostMapping("/addEdit/shippingaddress")
		private String insertOrUpdateShippingaddress(Shippingaddress shippingaddress, User user) {
			if (shippingaddress.getShippingID() == null) {
				addressRepository.save(shippingaddress);
			} else {
				Optional<Shippingaddress> shippingaddressOptional = addressRepository.findById(shippingaddress.getShippingID());
				if (shippingaddressOptional.isPresent()) {
					Shippingaddress editShippingaddress = shippingaddressOptional.get();
					editShippingaddress.setStreet(shippingaddress.getStreet());
					editShippingaddress.setApt(shippingaddress.getApt());
					editShippingaddress.setCity(shippingaddress.getCity());
					editShippingaddress.setState(shippingaddress.getState());
					editShippingaddress.setZipcode(shippingaddress.getZipcode());
					editShippingaddress.setCountry(shippingaddress.getCountry());
					addressRepository.save(editShippingaddress);
				}
			}
			return "redirect:/api/users/list/shippingaddress";
		}
		
	// delete user by id
	@GetMapping("/delete/{id}")
	private String deleteUser(@PathVariable("id") Long id) {
		Optional<User> user = userRepository.findById(id);
		if (user.isPresent()) {
			userRepository.delete(user.get());
		} else {
			System.err.println("not found");
		}
		return "redirect:/api/users/list";
	}
	
	// delete creditcard by id
	@GetMapping("/delete/creditcard/{id}")
	private String deleteUserCreditcard(@PathVariable("id") Long CreditCardID) {
		Optional<Creditcard> creditcard = creditRepository.findById(CreditCardID);
		if (creditcard.isPresent()) {
			creditRepository.delete(creditcard.get());
		} else {
			System.err.println("not found");
		}
		return "redirect:/api/users/list/creditcard";
	}
	
	// delete shipping address by id
		@GetMapping("/delete/shippingaddress/{id}")
		private String deleteUserShippingaddress(@PathVariable("id") Long shippingID) {
			Optional<Shippingaddress> shippingaddress = addressRepository.findById(shippingID);
			if (shippingaddress.isPresent()) {
				addressRepository.delete(shippingaddress.get());
			} else {
				System.err.println("not found");
			}
			return "redirect:/api/users/list/shippingaddress";
		}
		
		/*
		 * // get creditcard by user id
		 * 
		 * @GetMapping("/{id}/creditcards") public String getCreditcardsByUser
		 * (@PathVariable("id") Long id, Model model) { List<Creditcard> creditcard =
		 * (List<Creditcard>) userRepository.getCreditCardsByUser(id);
		 * model.addAttribute("users", creditcard); return "user_credit_id"; }
		 * 
		 * // get creditcard by user id
		 * 
		 * @GetMapping("/{id}/address") public String getShippingaddressByUser
		 * (@PathVariable("id") Long id, Model model) { List<Shippingaddress>
		 * shippingaddress = (List<Shippingaddress>)
		 * userRepository.getShippingAddressByUser(id); model.addAttribute("users",
		 * shippingaddress); return "user_address_id"; }
		 */
	
	// login using current credentials
	
//	@GetMapping("/list")
//	private String getAll(Model model) {
//		model.addAttribute("users", userRepository.findAll());
//		return "user_list";
//	}

//	// get shipping address by user id
//	@GetMapping("/{id}/shippingaddress")
//	public List<Shippingaddress> getShippingaddressByUser(@PathVariable("id") Long id) {
//		return userRepository.getShippingAddressByUser(id);
//	}
	
//
//	// get all users
//	@GetMapping
//	public List<User> getAllUsers() {
//		return this.userRepository.findAll();
//	}
//
//	// get user by id
//	@GetMapping("/{id}")
//	public User getUserById(@PathVariable(value = "id") long id) {
//		return this.userRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + id));
//	}
//
//	// create user
//	@PostMapping
//	public User createUser(@RequestBody User user) {
//		return this.userRepository.save(user);
//	}
//
//	// update user
//	@PutMapping("/{id}")
//	public User updateUser(@RequestBody User user, @PathVariable("id") long id) {
//		User existingUser = this.userRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + id));
//		existingUser.setUsername(user.getUsername());
//		existingUser.setPassword(user.getPassword());
//		existingUser.setFirstname(user.getFirstname());
//		existingUser.setLastname(user.getLastname());
//		existingUser.setEmail(user.getEmail());
//		existingUser.setNickname(user.getNickname());
//		return this.userRepository.save(existingUser);
//	}
//
//	// delete user by id
//	@DeleteMapping("/{id}")
//	public ResponseEntity<User> deleteUser(@PathVariable("id") long id) {
//		User existingUser = this.userRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + id));
//		this.userRepository.delete(existingUser);
//		return ResponseEntity.ok().build();
//	}
//
//	@GetMapping("/{id}/creditcards")
//	public List<Creditcard> getCreditcardByUser(@PathVariable("id") Long id) {
//		return userRepository.getCreditCardsByUser(id);
//	}
//
//	@GetMapping("/{id}/shippingaddress")
//	public List<Shippingaddress> getShippingaddressByUser(@PathVariable("id") Long id) {
//		return userRepository.getShippingAddressByUser(id);
//	}
}
