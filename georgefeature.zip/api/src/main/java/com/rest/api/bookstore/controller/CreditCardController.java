package com.rest.api.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.api.exception.ResourceNotFoundException;
import com.rest.api.model.Creditcard;
import com.rest.api.repository.CreditCardRepository;


@RestController
@RequestMapping("/api/creditcards")
public class CreditCardController {

	@Autowired
	private CreditCardRepository creditCardRepository;

	// get all credit cards
	@GetMapping
	public List<Creditcard> getAllCreditcards() {
		return this.creditCardRepository.findAll();
	}

	// get individual credit card for the user based on creditcard id
	@GetMapping("/{UserID}/{CreditCardID}")
	public Creditcard getCreditCardById(@PathVariable("CreditCardID") long CreditCardID) {
		return this.creditCardRepository.findById(CreditCardID)
				.orElseThrow(() -> new ResourceNotFoundException("Credit card not found with id :" + CreditCardID));
	}

	// create credit card
	@PostMapping
	public Creditcard createCreditCard(@RequestBody Creditcard creditcard) {
		return this.creditCardRepository.save(creditcard);
	}

	// update credit card
	@PutMapping("/{CreditCardID}")
	public Creditcard updateCreditCard(@RequestBody Creditcard creditcard,
			@PathVariable("CreditCardID") long CreditCardID) {
		Creditcard existingCreditCard = this.creditCardRepository.findById(CreditCardID)
				.orElseThrow(() -> new ResourceNotFoundException("Credit card not found with id :" + CreditCardID));
		existingCreditCard.setCreditcardnumber(creditcard.getCreditcardnumber());
		existingCreditCard.setUser(creditcard.getUser());
		existingCreditCard.setCardname(creditcard.getCardname());
		existingCreditCard.setExpirationdate(creditcard.getExpirationdate());
		existingCreditCard.setCvv(creditcard.getCvv());
		return this.creditCardRepository.save(existingCreditCard);
	}

	// delete credit card by creditcard id
	@DeleteMapping("/{CreditCardID}")
	public ResponseEntity<Creditcard> deleteCreditCard(@PathVariable("CreditCardID") long CreditCardID) {
		Creditcard existingCreditCard = this.creditCardRepository.findById(CreditCardID)
				.orElseThrow(() -> new ResourceNotFoundException("Credit card not found with id :" + CreditCardID));
		this.creditCardRepository.delete(existingCreditCard);
		return ResponseEntity.ok().build();
	}
}
