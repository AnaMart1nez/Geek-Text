package com.rest.api.model;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.rest.api.repository.UserRepository;

@SuppressWarnings("serial")
public class UserPrinciple implements UserDetails{

	private User user;

	private UserRepository userRepository;


	public UserPrinciple(User user) {
		this.user = user;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Collections.singleton(new SimpleGrantedAuthority("USER"));
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return user.getPassword();
	}

	public String getFirstname() {
		// TODO Auto-generated method stub
		return user.getFirstname();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return user.getUsername();
	}

	public String getLastname() {
		// TODO Auto-generated method stub
		return user.getLastname();
	}

	public String getEmail() {
		// TODO Auto-generated method stub
		return user.getEmail();
	}

	public Long getId() {
		// TODO Auto-generated method stub
		return user.getId();
	}

	public String getNickname() {
		// TODO Auto-generated method stub
		return user.getNickname();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

	public Object findById(Long long1) {
		user.getId();
		return null;
	}

}
