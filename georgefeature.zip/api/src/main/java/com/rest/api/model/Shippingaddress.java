package com.rest.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table (name = "shippingaddress")

public class Shippingaddress {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Shippingid")
	private Long shippingID;
	
	@Column(name = "Street")
	private String street;

	@Column(name = "Apt")
	private String apt;
	
	@Column(name = "City")
	private String city;
	
	@Column(name = "State")
	private String state;
	
	@Column(name = "Zipcode")
	private String zipcode;
	
	@Column(name = "Country")
	private String country;
	
	@ManyToOne
	@JoinColumn(name = "UserID", nullable=false)
	private User user;
	
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Shippingaddress() {
		super();
	}

	public Shippingaddress(Long shippingID, String street, String apt, String city, String state,
			String zipcode, String country) {
		super();
		this.shippingID = shippingID;
		this.street = street;
		this.apt = apt;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.country = country;
	}

	public Long getShippingID() {
		return shippingID;
	}

	public void setShippingID(Long shippingID) {
		this.shippingID = shippingID;
	}


	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getApt() {
		return apt;
	}

	public void setApt(String apt) {
		this.apt = apt;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
}
