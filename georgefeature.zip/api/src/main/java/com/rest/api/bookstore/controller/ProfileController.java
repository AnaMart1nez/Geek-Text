package com.rest.api.bookstore.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rest.api.model.User;
import com.rest.api.model.UserPrinciple;
import com.rest.api.repository.CreditCardRepository;
import com.rest.api.repository.ShippingAddressRepository;
import com.rest.api.repository.UserRepository;
@Controller
public class ProfileController {

	@Autowired
	private UserRepository userRepository;
	private CreditCardRepository creditRepository;
	private ShippingAddressRepository addressRepository;

	
	// show all information from the user
		@GetMapping("/profile")
		public String showUserAccount (String username, Model model) {
			User user = userRepository.findByUsername(username);
			model.addAttribute("user", user);
			return "profile";
		}
		
		// add or edit users
		@GetMapping(path = { "/profile/edit/{id}" })
		private String addForm(@PathVariable("id") Optional<Long> id, Model model, User user) {
			if (id.isPresent()) {
				model.addAttribute("user", userRepository.findById(id.get()));
			} else {
				model.addAttribute("user", new User());
			}
			return "add_edit_user";
		}
		
		@PostMapping("/profile/addedit")
		private String insertOrUpdate(UserPrinciple user) {
			if (user.getId() == null) {
				userRepository.save(user);
			} else {
				Optional<User> userOptional = userRepository.findById(user.getId());
				if (userOptional.isPresent()) {
					User editUser = userOptional.get();
					editUser.setUsername(user.getUsername());
					editUser.setPassword(user.getPassword());
					editUser.setFirstname(user.getFirstname());
					editUser.setLastname(user.getLastname());
					editUser.setEmail(user.getEmail());
					editUser.setNickname(user.getNickname());
					userRepository.save(editUser);
				}
			}
			return "redirect:/index";
		}
}
