package com.rest.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rest.api.model.User;
import com.rest.api.model.UserPrinciple;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	
	/*
	 * @Query("select creditcard from User u where u.id = ?1") List<Creditcard>
	 * getCreditCardsByUser(Long id);
	 */

	User findByUsername(String username);

	void save(UserPrinciple user);

	
	/*
	 * @Query("select shippingaddress from User u where u.id = ?1")
	 * List<Shippingaddress> getShippingAddressByUser(Long id);
	 */


}
