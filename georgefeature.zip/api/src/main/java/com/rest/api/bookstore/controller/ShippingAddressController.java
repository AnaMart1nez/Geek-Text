package com.rest.api.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.api.exception.ResourceNotFoundException;
import com.rest.api.model.Shippingaddress;
import com.rest.api.repository.ShippingAddressRepository;

@RestController
@RequestMapping("/api/shippingaddress")
public class ShippingAddressController {

	@Autowired
	private ShippingAddressRepository shippingAddressRepository;

	// get all shipping addresses
	@GetMapping
	public List<Shippingaddress> getAllShippingAddresses() {
		return this.shippingAddressRepository.findAll();
	}

	
	// get shipping address by id
	@GetMapping("/{UserID}/{ShippingID}")
	public Shippingaddress getShippingAddressById(@PathVariable (value = "ShippingID") long ShippingID) {
		return this.shippingAddressRepository.findById(ShippingID)
				.orElseThrow(() -> new ResourceNotFoundException("Shipping address not found with id :" + ShippingID));
	}

	// create user
	@PostMapping
	public Shippingaddress createShippingAddress(@RequestBody Shippingaddress shippingaddress) {
		return this.shippingAddressRepository.save(shippingaddress);
	}
	
	// update user
	@PutMapping("/{ShippingID}")
	public Shippingaddress updateUser(@RequestBody Shippingaddress shippingaddress, @PathVariable ("ShippingID") long ShippingID) {
		Shippingaddress existingShippingAddress = this.shippingAddressRepository.findById(ShippingID)
			.orElseThrow(() -> new ResourceNotFoundException("Shipping address not found with id :" + ShippingID));
		existingShippingAddress.setUser(shippingaddress.getUser());
		existingShippingAddress.setStreet(shippingaddress.getStreet());
		existingShippingAddress.setApt(shippingaddress.getApt());
		existingShippingAddress.setCity(shippingaddress.getCity());
		existingShippingAddress.setState(shippingaddress.getState());
		existingShippingAddress.setZipcode(shippingaddress.getZipcode());
		existingShippingAddress.setCountry(shippingaddress.getCountry());
		 return this.shippingAddressRepository.save(existingShippingAddress);
	}
	
	// delete user by id
	@DeleteMapping("/{ShippingID}")
	public ResponseEntity<Shippingaddress> deleteShippingAddress(@PathVariable ("ShippingID") long ShippingID){
		Shippingaddress existingShippingAddress = this.shippingAddressRepository.findById(ShippingID)
					.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + ShippingID));
		 this.shippingAddressRepository.delete(existingShippingAddress);
		 return ResponseEntity.ok().build();
	}
}
